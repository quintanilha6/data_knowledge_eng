param($installPath, $toolsPath, $package, $project)

