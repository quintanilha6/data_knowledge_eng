﻿using System.Web.UI;

namespace TrabalhoFinal.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}