﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TrabalhoFinal.Startup))]
namespace TrabalhoFinal
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
